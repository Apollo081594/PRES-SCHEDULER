﻿namespace PRES_Scheduler
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tbDataDir = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tbPressPath = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.tbPDCFile = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnPRESFILE = new System.Windows.Forms.Button();
            this.btnPDCFile = new System.Windows.Forms.Button();
            this.btnDataDir = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(17, 57);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(359, 290);
            this.listBox1.TabIndex = 0;
            // 
            // tbDataDir
            // 
            this.tbDataDir.Location = new System.Drawing.Point(17, 27);
            this.tbDataDir.Name = "tbDataDir";
            this.tbDataDir.Size = new System.Drawing.Size(294, 20);
            this.tbDataDir.TabIndex = 1;
            this.tbDataDir.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(17, 359);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(359, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "PROCESS";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tbPressPath
            // 
            this.tbPressPath.Location = new System.Drawing.Point(3, 14);
            this.tbPressPath.Name = "tbPressPath";
            this.tbPressPath.ReadOnly = true;
            this.tbPressPath.Size = new System.Drawing.Size(425, 20);
            this.tbPressPath.TabIndex = 5;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 395);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(946, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Black;
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox2.ForeColor = System.Drawing.Color.White;
            this.richTextBox2.Location = new System.Drawing.Point(3, 16);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(477, 234);
            this.richTextBox2.TabIndex = 9;
            this.richTextBox2.Text = "";
            // 
            // tbPDCFile
            // 
            this.tbPDCFile.Location = new System.Drawing.Point(6, 13);
            this.tbPDCFile.Multiline = true;
            this.tbPDCFile.Name = "tbPDCFile";
            this.tbPDCFile.ReadOnly = true;
            this.tbPDCFile.Size = new System.Drawing.Size(422, 71);
            this.tbPDCFile.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.richTextBox2);
            this.groupBox1.Location = new System.Drawing.Point(401, 138);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(483, 253);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Console:";
            // 
            // btnPRESFILE
            // 
            this.btnPRESFILE.Location = new System.Drawing.Point(440, 14);
            this.btnPRESFILE.Name = "btnPRESFILE";
            this.btnPRESFILE.Size = new System.Drawing.Size(56, 20);
            this.btnPRESFILE.TabIndex = 12;
            this.btnPRESFILE.Text = "Browse";
            this.btnPRESFILE.UseVisualStyleBackColor = true;
            this.btnPRESFILE.Click += new System.EventHandler(this.btnPRESFILE_Click);
            // 
            // btnPDCFile
            // 
            this.btnPDCFile.Location = new System.Drawing.Point(440, 13);
            this.btnPDCFile.Name = "btnPDCFile";
            this.btnPDCFile.Size = new System.Drawing.Size(56, 71);
            this.btnPDCFile.TabIndex = 13;
            this.btnPDCFile.Text = "Browse";
            this.btnPDCFile.UseVisualStyleBackColor = true;
            this.btnPDCFile.Click += new System.EventHandler(this.btnPDCFile_Click);
            // 
            // btnDataDir
            // 
            this.btnDataDir.Location = new System.Drawing.Point(320, 27);
            this.btnDataDir.Name = "btnDataDir";
            this.btnDataDir.Size = new System.Drawing.Size(56, 20);
            this.btnDataDir.TabIndex = 14;
            this.btnDataDir.Text = "Browse";
            this.btnDataDir.UseVisualStyleBackColor = true;
            this.btnDataDir.Click += new System.EventHandler(this.btnDataDir_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbPressPath);
            this.groupBox2.Controls.Add(this.btnPRESFILE);
            this.groupBox2.Location = new System.Drawing.Point(401, 1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(503, 41);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PRES File";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnPDCFile);
            this.groupBox3.Controls.Add(this.tbPDCFile);
            this.groupBox3.Location = new System.Drawing.Point(401, 48);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(503, 90);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "PDC FILE ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 417);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnDataDir);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tbDataDir);
            this.Controls.Add(this.listBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "PRES SCHEDULER";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox tbDataDir;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tbPressPath;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.TextBox tbPDCFile;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPRESFILE;
        private System.Windows.Forms.Button btnPDCFile;
        private System.Windows.Forms.Button btnDataDir;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}

