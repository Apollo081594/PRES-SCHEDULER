﻿using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace PRES_Scheduler
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string appStart = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string finPath = tbDataDir.Text + "\\FIN";

                if (listBox1.Items.Count > 0)
                {
                    if (!Directory.Exists(finPath))
                    {
                        Directory.CreateDirectory(finPath);
                    }

                    if (!File.Exists(tbPDCFile.Text.Trim()))
                    {
                        MessageBox.Show("Invalid PDC File Path!");
                        return;
                    }
                    if (!File.Exists(tbPressPath.Text.Trim()))
                    {
                        MessageBox.Show("Invalid PRES File Path!");
                        return;
                    }
                    for (int i = 0; i < listBox1.Items.Count; i++)
                    {
                        listBox1.SelectedIndex = i;
                        richTextBox2.AppendText($"SysTime: {DateTime.Now.ToString()} :  Processing: {listBox1.Items[i].ToString()} ... {Environment.NewLine}");
                       
                        ProcessStartInfo processStartInfo = new ProcessStartInfo();
                        
                        processStartInfo.FileName = tbPressPath.Text;
                     
                        processStartInfo.Arguments = $"\"{tbPDCFile.Text.Trim()}\" DATA=\"{tbDataDir.Text + "\\" + listBox1.Items[i].ToString()}\" START";
                        processStartInfo.WindowStyle = ProcessWindowStyle.Normal;

                        var pPDC = Process.Start(processStartInfo);
                        pPDC.WaitForExit();
                        
                        File.Move(tbDataDir.Text + "\\" + listBox1.Items[i].ToString(), finPath + "\\" + listBox1.Items[i].ToString());

                        toolStripStatusLabel1.Text = $"Total Processed: {i}";
                    }
                    richTextBox2.AppendText($"SysTime: {DateTime.Now.ToString()} :  FINISH! {Environment.NewLine}");

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally {
                MessageBox.Show("Finish!");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            listBox1.Items.Clear();
            DirectoryInfo dinfo = new DirectoryInfo(tbDataDir.Text);


            FileInfo[] Files = dinfo.GetFiles("*.txt*");

            foreach (FileInfo file in Files)
            {
                string getfilename = Path.GetFileName(file.Name);
                listBox1.Items.Add(getfilename);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {

                using (StreamWriter w = new StreamWriter(appStart + "\\setup.chn", false))
                {
                    w.WriteLine(tbPressPath.Text);
                    w.WriteLine(tbPDCFile.Text);
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(appStart + "\\setup.chn"))
                {
                    using (StreamReader r = new StreamReader(appStart + "\\setup.chn"))
                    {
                        string line = r.ReadLine();
                        tbPressPath.Text = line;
                        line = r.ReadLine();
                        tbPDCFile.Text = line;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnPRESFILE_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    tbPressPath.Text = openFileDialog1.FileName;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnPDCFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    tbPDCFile.Text = openFileDialog1.FileName;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnDataDir_Click(object sender, EventArgs e)
        {
            try
            {
                if (Directory.Exists(tbDataDir.Text.Trim()))
                {
                    folderBrowserDialog1.SelectedPath = tbDataDir.Text.Trim();
                }
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    tbDataDir.Text = folderBrowserDialog1.SelectedPath;
                }

                listBox1.Items.Clear();
                DirectoryInfo dinfo = new DirectoryInfo(tbDataDir.Text);

                FileInfo[] Files = dinfo.GetFiles("*.txt*");

                foreach (FileInfo file in Files)
                {
                    string getfilename = Path.GetFileName(file.Name);
                    listBox1.Items.Add(getfilename);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
